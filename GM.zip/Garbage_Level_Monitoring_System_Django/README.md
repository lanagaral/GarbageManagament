# Garbage-Level-Monitoring-System
My BE Project using IoT, Cloud and Django

# Results

Global Dashboard Provided to monitor garbage levels in real-time
![Dashboard1](results/SGLM_Dashboard.png "Main Dashboard")

<br />

Getting more information after clicking on a specific garbage bin icon on dashboard
![Dashboard2](results/SGLM_Dashboard1.png "Dashboard after clicking on a specific bin icon")
